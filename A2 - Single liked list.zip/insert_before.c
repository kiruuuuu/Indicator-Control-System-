#include "sll.h"

int sl_insert_before(Slist **head, data_t g_data, data_t ndata)
{

}