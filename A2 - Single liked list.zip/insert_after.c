#include "sll.h"

int sl_insert_after(Slist **head, data_t g_data, data_t ndata)
{

}