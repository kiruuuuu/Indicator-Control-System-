#include "sll.h"

int sl_delete_element(Slist **head, data_t data)
{

}