#include "sll.h"

int sl_insert_nth(Slist **head, data_t data, data_t n)
{

}